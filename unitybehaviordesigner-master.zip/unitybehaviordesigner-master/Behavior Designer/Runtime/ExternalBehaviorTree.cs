namespace BehaviorDesigner.Runtime
{
    [System.Serializable]
    public class ExternalBehaviorTree : ExternalBehavior
    {
        // intentionally left blank
    }
}